
import { GoogleGenAI, Type } from "@google/genai";
import { ExamRecord } from "../types";

/**
 * Extracts exam arrangement records from multiple base64 image strings using Gemini Vision.
 */
export async function extractExamDataFromImages(base64Images: string[]): Promise<ExamRecord[]> {
  // Always instantiate the client inside the call to ensure the latest API key from process.env is used.
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  // Use gemini-3-pro-preview for complex OCR and structured data extraction from multi-page documents.
  const model = "gemini-3-pro-preview";
  
  // Create parts for all pages
  const imageParts = base64Images.map(base64 => ({
    inlineData: {
      data: base64.split(',')[1] || base64, // Strip base64 prefix if exists
      mimeType: "image/jpeg"
    }
  }));

  const prompt = `
    Extract data from these exam hall arrangement documents. 
    Find every instance where there is a Hall Name/Number, a Course Code, and a Question Paper (QP) Count.
    The output must be a clean list of records following the defined schema.
  `;

  const response = await ai.models.generateContent({
    model,
    contents: { parts: [...imageParts, { text: prompt }] },
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            hall: { type: Type.STRING, description: "The hall name or number (e.g., 'LH-01', 'Room 203')" },
            courseCode: { type: Type.STRING, description: "The course code (e.g., 'CS101', 'MATH-II')" },
            qpCount: { type: Type.NUMBER, description: "The number of question papers" }
          },
          required: ["hall", "courseCode", "qpCount"]
        }
      }
    }
  });

  const text = response.text;
  if (!text) return [];
  
  try {
    return JSON.parse(text) as ExamRecord[];
  } catch (error) {
    console.error("Failed to parse Gemini response", error);
    return [];
  }
}
