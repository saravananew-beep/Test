
export interface ExamRecord {
  hall: string;
  courseCode: string;
  qpCount: number;
}

export interface AggregatedRecord {
  hall: string;
  courseCode: string;
  totalQpCount: number;
}

export interface HallSummary {
  hall: string;
  totalQpCount: number;
}

export interface CourseSummary {
  courseCode: string;
  totalQpCount: number;
}

export interface ProcessingState {
  status: 'idle' | 'loading' | 'success' | 'error';
  message: string;
}
