import React, { useState, useMemo, useRef } from 'react';
import { 
  FileUp, FileText, Download, Loader2, AlertCircle, 
  CheckCircle2, LayoutDashboard, Hash, Layers, Info, FileSpreadsheet, GraduationCap, Trash2
} from 'lucide-react';
import { AggregatedRecord, ProcessingState, ExamRecord, HallSummary, CourseSummary } from './types';
import { convertPdfToImages } from './utils/pdfProcessor';
import { extractExamDataFromImages } from './services/geminiService';
import { exportToExcel, exportToPdf } from './utils/exportUtils';

type TabType = 'details' | 'hall' | 'course';

const App: React.FC = () => {
  const [data, setData] = useState<AggregatedRecord[]>([]);
  const [processing, setProcessing] = useState<ProcessingState>({ status: 'idle', message: '' });
  const [dragActive, setDragActive] = useState(false);
  const [activeTab, setActiveTab] = useState<TabType>('details');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const naturalSort = (a: string, b: string) => 
    a.localeCompare(b, undefined, { numeric: true, sensitivity: 'base' });

  // Consolidation logic applied to the current state
  const displayData = useMemo(() => {
    return [...data].sort((a, b) => naturalSort(a.hall, b.hall) || naturalSort(a.courseCode, b.courseCode));
  }, [data]);

  const hallSummaries = useMemo<HallSummary[]>(() => {
    const map = new Map<string, number>();
    data.forEach(d => {
      map.set(d.hall, (map.get(d.hall) || 0) + d.totalQpCount);
    });
    return Array.from(map.entries())
      .map(([hall, totalQpCount]) => ({ hall, totalQpCount }))
      .sort((a, b) => naturalSort(a.hall, b.hall));
  }, [data]);

  const courseSummaries = useMemo<CourseSummary[]>(() => {
    const map = new Map<string, number>();
    data.forEach(d => {
      map.set(d.courseCode, (map.get(d.courseCode) || 0) + d.totalQpCount);
    });
    return Array.from(map.entries())
      .map(([courseCode, totalQpCount]) => ({ courseCode, totalQpCount }))
      .sort((a, b) => naturalSort(a.courseCode, b.courseCode));
  }, [data]);

  const stats = useMemo(() => {
    const totalQPs = data.reduce((sum, item) => sum + item.totalQpCount, 0);
    const uniqueHalls = new Set(data.map(d => d.hall.trim().toUpperCase())).size;
    const uniqueCourses = new Set(data.map(d => d.courseCode.trim().toUpperCase())).size;
    return { totalQPs, uniqueHalls, uniqueCourses };
  }, [data]);

  const clearData = () => {
    if (window.confirm("Are you sure you want to clear all data? This cannot be undone.")) {
      setData([]);
      setProcessing({ status: 'idle', message: '' });
      // Crucial: Reset the file input value so the same file can be uploaded again
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  const processFiles = async (files: FileList | File[]) => {
    const fileList = Array.from(files).filter(f => f.type.includes('pdf') || f.name.toLowerCase().endsWith('.pdf'));
    
    if (fileList.length === 0) {
      setProcessing({ status: 'error', message: 'Please upload valid PDF documents.' });
      return;
    }

    setProcessing({ status: 'loading', message: `Initializing ${fileList.length} file(s)...` });
    
    try {
      const allExtracted: ExamRecord[] = [];

      for (let i = 0; i < fileList.length; i++) {
        const file = fileList[i];
        setProcessing({ status: 'loading', message: `Rendering PDF pages (${i + 1}/${fileList.length})...` });
        const images = await convertPdfToImages(file);
        
        setProcessing({ status: 'loading', message: `AI Analysis in progress (File ${i + 1})...` });
        const records = await extractExamDataFromImages(images);
        allExtracted.push(...records);
      }

      if (allExtracted.length === 0) {
        throw new Error("Could not extract any meaningful data. Please check the PDF layout.");
      }

      // Merge and aggregate logic
      setData(prev => {
        const aggregator = new Map<string, number>();
        const labelMap = new Map<string, { h: string, c: string }>();

        const ingest = (h: string, c: string, count: number) => {
          const hallClean = h.trim();
          const courseClean = c.trim();
          const key = `${hallClean.toUpperCase()}|${courseClean.toUpperCase()}`;
          
          aggregator.set(key, (aggregator.get(key) || 0) + count);
          
          if (!labelMap.has(key)) {
            labelMap.set(key, { h: hallClean, c: courseClean });
          }
        };

        // Re-ingest current data
        prev.forEach(item => ingest(item.hall, item.courseCode, item.totalQpCount));
        
        // Ingest newly extracted data
        allExtracted.forEach(record => ingest(record.hall, record.courseCode, record.qpCount));

        return Array.from(aggregator.entries()).map(([key, total]) => {
          const labels = labelMap.get(key)!;
          return {
            hall: labels.h,
            courseCode: labels.c,
            totalQpCount: total
          };
        });
      });

      setProcessing({ status: 'success', message: `Processing complete. Aggregated ${allExtracted.length} new entries.` });
    } catch (err: any) {
      console.error(err);
      setProcessing({ status: 'error', message: err.message || 'An error occurred during processing.' });
    }
  };

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    setDragActive(e.type === "dragenter" || e.type === "dragover");
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragActive(false);
    if (e.dataTransfer.files?.length > 0) processFiles(e.dataTransfer.files);
  };

  return (
    <div className="min-h-screen pb-12 bg-slate-50 text-slate-900">
      <header className="bg-[#000080] shadow-xl sticky top-0 z-20">
        <div className="max-w-6xl mx-auto py-3 px-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="bg-white p-2 rounded-full shadow-inner transform hover:rotate-12 transition-transform">
              <GraduationCap className="text-[#000080] w-6 h-6" />
            </div>
            <div>
              <h1 className="text-lg font-black text-white leading-none tracking-tighter uppercase">KAMARAJ</h1>
              <p className="text-[9px] text-white/70 font-bold uppercase tracking-widest">Question Paper Aggregator</p>
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            {data.length > 0 && (
              <>
                <button 
                  onClick={clearData} 
                  className="flex items-center gap-1.5 bg-slate-700 hover:bg-slate-800 text-white px-3 py-1.5 rounded text-[10px] font-bold transition-all border border-slate-600 shadow-sm active:scale-95"
                >
                  <Trash2 className="w-3.5 h-3.5" /> RESET
                </button>
                <button onClick={() => exportToExcel(displayData, hallSummaries, courseSummaries)} className="flex items-center gap-1.5 bg-emerald-600 hover:bg-emerald-700 text-white px-3 py-1.5 rounded text-[10px] font-bold transition-all shadow-lg active:scale-95">
                  <FileSpreadsheet className="w-3.5 h-3.5" /> EXCEL
                </button>
                <button onClick={() => exportToPdf(displayData, hallSummaries, courseSummaries)} className="flex items-center gap-1.5 bg-rose-600 hover:bg-rose-700 text-white px-3 py-1.5 rounded text-[10px] font-bold transition-all shadow-lg active:scale-95">
                  <Download className="w-3.5 h-3.5" /> PDF
                </button>
              </>
            )}
          </div>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-4 py-8 grid grid-cols-1 lg:grid-cols-4 gap-8">
        <aside className="space-y-6">
          <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-5">
            <h2 className="text-xs font-black text-slate-400 mb-4 uppercase tracking-widest flex items-center gap-2">
              <FileUp className="w-4 h-4 text-[#000080]" /> Import Schedules
            </h2>
            
            <div 
              className={`relative border-2 border-dashed rounded-xl p-8 text-center transition-all cursor-pointer ${dragActive ? 'border-indigo-500 bg-indigo-50' : 'border-slate-200 bg-slate-50 hover:bg-slate-100 hover:border-slate-300'}`}
              onDragEnter={handleDrag} onDragOver={handleDrag} onDragLeave={handleDrag} onDrop={handleDrop}
              onClick={() => fileInputRef.current?.click()}
            >
              <input 
                ref={fileInputRef}
                id="file-input" 
                type="file" 
                multiple 
                accept=".pdf" 
                className="hidden" 
                onChange={(e) => e.target.files && processFiles(e.target.files)} 
              />
              <FileUp className="w-10 h-10 text-slate-300 mx-auto mb-3" />
              <p className="text-xs font-bold text-slate-600">Drop PDF Schedules</p>
              <p className="text-[9px] text-slate-400 mt-1 uppercase tracking-tighter">Multiple Files Supported</p>
            </div>

            {processing.status !== 'idle' && (
              <div className={`mt-4 p-3 rounded-lg text-[10px] font-bold flex items-center gap-2 animate-fade-in border ${processing.status === 'loading' ? 'bg-blue-50 border-blue-100 text-blue-700' : processing.status === 'success' ? 'bg-emerald-50 border-emerald-100 text-emerald-700' : 'bg-rose-50 border-rose-100 text-rose-700'}`}>
                {processing.status === 'loading' && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
                {processing.status === 'success' && <CheckCircle2 className="w-3.5 h-3.5" />}
                {processing.status === 'error' && <AlertCircle className="w-3.5 h-3.5" />}
                <span className="truncate">{processing.message}</span>
              </div>
            )}
          </div>

          {data.length > 0 && (
            <div className="bg-[#000080] rounded-xl shadow-lg p-5 text-white space-y-4 animate-fade-in">
              <div className="flex items-center justify-between border-b border-white/10 pb-3">
                <div className="flex items-center gap-2">
                  <LayoutDashboard className="w-4 h-4 text-white/50" />
                  <span className="text-[10px] font-black uppercase tracking-widest text-white/70">Total Halls</span>
                </div>
                <span className="text-lg font-black">{stats.uniqueHalls}</span>
              </div>
              <div className="flex items-center justify-between border-b border-white/10 pb-3">
                <div className="flex items-center gap-2">
                  <Hash className="w-4 h-4 text-white/50" />
                  <span className="text-[10px] font-black uppercase tracking-widest text-white/70">Total Courses</span>
                </div>
                <span className="text-lg font-black">{stats.uniqueCourses}</span>
              </div>
              <div className="flex items-center justify-between pt-1">
                <div className="flex items-center gap-2">
                  <Layers className="w-4 h-4 text-amber-400" />
                  <span className="text-[10px] font-black uppercase tracking-widest text-amber-200">Total QP Count</span>
                </div>
                <span className="text-2xl font-black text-white">{stats.totalQPs}</span>
              </div>
            </div>
          )}
          
          <div className="bg-indigo-50 border border-indigo-100 rounded-xl p-4">
            <h4 className="text-[10px] font-black text-indigo-900 uppercase tracking-widest mb-2 flex items-center gap-2">
              <Info className="w-3 h-3" /> Aggregation Note
            </h4>
            <p className="text-[10px] text-indigo-700 leading-relaxed">
              When the same <strong>Hall</strong> and <strong>Course Code</strong> appear multiple times, the QP counts are automatically summed into a single entry.
            </p>
          </div>
        </aside>

        <section className="lg:col-span-3">
          <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden flex flex-col h-[650px]">
            <nav className="flex items-center px-4 bg-slate-50 border-b border-slate-200 overflow-x-auto scrollbar-hide">
              {(['details', 'hall', 'course'] as TabType[]).map((tab) => (
                <button
                  key={tab}
                  onClick={() => setActiveTab(tab)}
                  className={`px-5 py-3.5 text-[10px] font-black uppercase tracking-widest transition-all relative whitespace-nowrap ${activeTab === tab ? 'text-[#000080]' : 'text-slate-400 hover:text-slate-600'}`}
                >
                  {tab === 'details' ? 'Consolidated Data' : tab === 'hall' ? 'Summary by Hall' : 'Summary by Course'}
                  {activeTab === tab && <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-[#000080]" />}
                </button>
              ))}
            </nav>

            <div className="flex-1 overflow-auto">
              {data.length > 0 ? (
                <table className="w-full text-left border-collapse">
                  <thead className="sticky top-0 bg-white/95 backdrop-blur z-10 border-b border-slate-100">
                    <tr>
                      <th className="px-6 py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">
                        {activeTab === 'course' ? 'Course Code' : 'Hall Name'}
                      </th>
                      {activeTab === 'details' && (
                        <th className="px-6 py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">Course Code</th>
                      )}
                      <th className="px-6 py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest text-right">
                        QP Count
                      </th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-50">
                    {activeTab === 'details' && displayData.map((r, i) => (
                      <tr key={i} className="hover:bg-slate-50 transition-colors">
                        <td className="px-6 py-4 text-xs font-bold text-slate-900">{r.hall}</td>
                        <td className="px-6 py-4">
                          <span className="bg-slate-100 px-2 py-0.5 rounded border border-slate-200 text-[10px] font-mono font-bold text-slate-600">
                            {r.courseCode}
                          </span>
                        </td>
                        <td className="px-6 py-4 text-xs font-mono font-black text-right text-[#000080]">{r.totalQpCount}</td>
                      </tr>
                    ))}
                    {activeTab === 'hall' && hallSummaries.map((r, i) => (
                      <tr key={i} className="hover:bg-slate-50 transition-colors">
                        <td className="px-6 py-4 text-xs font-bold text-slate-900">{r.hall}</td>
                        <td className="px-6 py-4 text-xs font-mono font-black text-right text-[#000080]">{r.totalQpCount}</td>
                      </tr>
                    ))}
                    {activeTab === 'course' && courseSummaries.map((r, i) => (
                      <tr key={i} className="hover:bg-slate-50 transition-colors">
                        <td className="px-6 py-4 text-xs font-mono font-bold text-slate-800">{r.courseCode}</td>
                        <td className="px-6 py-4 text-xs font-mono font-black text-right text-emerald-700">{r.totalQpCount}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              ) : (
                <div className="h-full flex flex-col items-center justify-center text-slate-200 gap-4 opacity-40">
                  <FileText className="w-20 h-20 stroke-[1]" />
                  <p className="text-xs font-black uppercase tracking-widest">Awaiting PDF Upload...</p>
                </div>
              )}
            </div>
          </div>
        </section>
      </main>
    </div>
  );
};

export default App;