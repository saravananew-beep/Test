
import * as pdfjs from 'pdfjs-dist';

// Synchronized with the version in index.html importmap
const PDFJS_VERSION = '4.4.168';
pdfjs.GlobalWorkerOptions.workerSrc = `https://cdnjs.cloudflare.com/ajax/libs/pdf.js/${PDFJS_VERSION}/pdf.worker.min.mjs`;

export async function convertPdfToImages(file: File): Promise<string[]> {
  try {
    const arrayBuffer = await file.arrayBuffer();
    
    // Check version consistency before processing
    if (pdfjs.version !== PDFJS_VERSION) {
       console.warn(`Version Mismatch Detected: API (${pdfjs.version}) vs Worker Config (${PDFJS_VERSION})`);
    }

    const loadingTask = pdfjs.getDocument({ 
      data: arrayBuffer,
      useWorkerFetch: true,
      isEvalSupported: false 
    });
    
    const pdf = await loadingTask.promise;
    const images: string[] = [];

    for (let i = 1; i <= pdf.numPages; i++) {
      const page = await pdf.getPage(i);
      const viewport = page.getViewport({ scale: 2.0 }); 
      const canvas = document.createElement('canvas');
      const context = canvas.getContext('2d');
      
      if (!context) continue;
      
      canvas.height = viewport.height;
      canvas.width = viewport.width;

      // Fix: The 'canvas' property is required in some versions of RenderParameters types for pdf.js
      await page.render({
        canvasContext: context as any,
        viewport: viewport,
        canvas: canvas as any,
      }).promise;

      images.push(canvas.toDataURL('image/jpeg', 0.85));
      page.cleanup();
    }

    return images;
  } catch (error: any) {
    console.error("PDF Processing Error:", error);
    if (error.message?.includes('version')) {
      throw new Error(`PDF Library Mismatch: API ${pdfjs.version} vs Worker ${PDFJS_VERSION}. The application needs to use identical versions for both.`);
    }
    throw new Error("Failed to process the PDF file. Please ensure it is a valid document.");
  }
}
