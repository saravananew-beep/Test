
import { utils, writeFile } from 'xlsx';
import { jsPDF } from 'jspdf';
import autoTable from 'jspdf-autotable';
import { AggregatedRecord, HallSummary, CourseSummary } from '../types';

// Export constants for use in other components to maintain consistent branding
export const COLLEGE_NAME = 'KAMARAJ COLLEGE OF ENGINEERING & TECHNOLOGY';
export const AFFILIATION = '(An Autonomous Institution - AFFILIATED TO ANNA UNIVERSITY, CHENNAI)';
export const CAMPUS_INFO = 'S.P.G.Chidambara Nadar - C.Nagammal Campus';
export const ADDRESS_INFO = 'S.P.G.C.Nagar, K.Vellakulam - 625 701, (Near Virudhunagar), Madurai District.';

export function exportToExcel(
  details: AggregatedRecord[], 
  hallSummary: HallSummary[], 
  courseSummary: CourseSummary[]
) {
  const workbook = utils.book_new();

  // Primary Hall-wise report
  const hallGroups = new Map<string, AggregatedRecord[]>();
  details.forEach(record => {
    if (!hallGroups.has(record.hall)) hallGroups.set(record.hall, []);
    hallGroups.get(record.hall)!.push(record);
  });

  const hallReportData: any[] = [];
  
  // Header section for Excel with full details
  hallReportData.push({ 'Col1': COLLEGE_NAME, 'Col2': '', 'Col3': '' });
  hallReportData.push({ 'Col1': AFFILIATION, 'Col2': '', 'Col3': '' });
  hallReportData.push({ 'Col1': CAMPUS_INFO, 'Col2': '', 'Col3': '' });
  hallReportData.push({ 'Col1': ADDRESS_INFO, 'Col2': '', 'Col3': '' });
  hallReportData.push({}); 
  hallReportData.push({ 'Col1': 'EXAM QUESTION PAPER ARRANGEMENT REPORT', 'Col2': '', 'Col3': '' });
  hallReportData.push({}); 

  hallGroups.forEach((records, hallName) => {
    hallReportData.push({ 'Col1': `Hall Name : ${hallName}`, 'Col2': '', 'Col3': '' });
    hallReportData.push({ 'Col1': 'Course code', 'Col2': 'QP Count', 'Col3': '' });
    
    let hallTotalQp = 0;
    records.forEach(r => {
      hallReportData.push({ 'Col1': r.courseCode, 'Col2': r.totalQpCount, 'Col3': '' });
      hallTotalQp += r.totalQpCount;
    });

    hallReportData.push({ 
      'Col1': `Total course: ${records.length}`, 
      'Col2': `Total QP: ${hallTotalQp}`,
      'Col3': ''
    });
    hallReportData.push({}); 
  });

  const hallSheet = utils.json_to_sheet(hallReportData, { skipHeader: true });
  hallSheet['!cols'] = [{ wch: 50 }, { wch: 20 }, { wch: 10 }];
  utils.book_append_sheet(workbook, hallSheet, 'Hall-wise Report');

  // Summary Sheet
  const totalQPs = details.reduce((sum, item) => sum + item.totalQpCount, 0);
  const summaryData = [
    { 'Institution': COLLEGE_NAME },
    { 'Category': 'Total Halls', 'Value': hallSummary.length },
    { 'Category': 'Total Unique Courses', 'Value': courseSummary.length },
    { 'Category': 'Grand Total QP Count', 'Value': totalQPs },
  ];
  const summarySheet = utils.json_to_sheet(summaryData);
  utils.book_append_sheet(workbook, summarySheet, 'Executive Summary');

  writeFile(workbook, 'Kamaraj_Exam_Report.xlsx');
}

export function exportToPdf(
  details: AggregatedRecord[], 
  hallSummary: HallSummary[], 
  courseSummary: CourseSummary[]
) {
  const doc = new jsPDF();
  const timestamp = new Date().toLocaleString();
  const totalQPs = details.reduce((sum, item) => sum + item.totalQpCount, 0);

  // Institution Header (Matching Logo Content)
  doc.setFontSize(16);
  doc.setTextColor(20, 30, 120); // Deep Royal Blue
  doc.setFont('helvetica', 'bold');
  doc.text(COLLEGE_NAME, 105, 15, { align: 'center' });
  
  doc.setFontSize(8);
  doc.setTextColor(60, 60, 60);
  doc.setFont('helvetica', 'normal');
  doc.text(AFFILIATION, 105, 20, { align: 'center' });
  doc.text(CAMPUS_INFO, 105, 24, { align: 'center' });
  doc.text(ADDRESS_INFO, 105, 28, { align: 'center' });

  doc.setFontSize(12);
  doc.setTextColor(40, 40, 40);
  doc.setFont('helvetica', 'bold');
  doc.text('EXAM HALL QUESTION PAPER REPORT', 105, 38, { align: 'center' });
  
  doc.setFontSize(7);
  doc.setTextColor(120, 120, 120);
  doc.setFont('helvetica', 'normal');
  doc.text(`Generated: ${timestamp}`, 14, 42);

  const hallGroups = new Map<string, AggregatedRecord[]>();
  details.forEach(record => {
    if (!hallGroups.has(record.hall)) hallGroups.set(record.hall, []);
    hallGroups.get(record.hall)!.push(record);
  });

  let currentY = 50;

  hallGroups.forEach((records, hallName) => {
    if (currentY > 240) {
      doc.addPage();
      currentY = 20;
    }

    doc.setFontSize(11);
    doc.setTextColor(0, 0, 0);
    doc.setFont('helvetica', 'bold');
    doc.text(`Hall Name : ${hallName}`, 14, currentY);
    
    let hallTotalQp = 0;
    const tableBody = records.map(r => {
      hallTotalQp += r.totalQpCount;
      return [r.courseCode, r.totalQpCount];
    });

    autoTable(doc, {
      startY: currentY + 3,
      head: [['Course code', 'QP Count']],
      body: tableBody,
      theme: 'grid',
      headStyles: { fillColor: [20, 30, 120], textColor: [255, 255, 255], fontStyle: 'bold' },
      styles: { fontSize: 9, cellPadding: 2 },
      margin: { left: 14, right: 14 },
      didDrawPage: (data) => {
        currentY = (data.cursor?.y || currentY);
      }
    });

    currentY += 8;
    doc.setFontSize(10);
    doc.setFont('helvetica', 'bold');
    doc.text(`Total course: ${records.length}    Total QP: ${hallTotalQp}`, 14, currentY);
    
    currentY += 15;
  });

  // Final Summary
  if (currentY > 250) {
    doc.addPage();
    currentY = 20;
  }
  doc.setDrawColor(20, 30, 120);
  doc.line(14, currentY, 196, currentY);
  currentY += 10;
  doc.setFontSize(12);
  doc.text('Grand Session Summary', 14, currentY);
  currentY += 8;
  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  doc.text(`Total Halls: ${hallSummary.length}`, 14, currentY);
  doc.text(`Total Unique Courses: ${courseSummary.length}`, 80, currentY);
  doc.setFont('helvetica', 'bold');
  doc.text(`Grand Total QP: ${totalQPs}`, 150, currentY);

  const pageCount = doc.getNumberOfPages();
  for(let i = 1; i <= pageCount; i++) {
    doc.setPage(i);
    doc.setFontSize(8);
    doc.setTextColor(150);
    doc.text(`${COLLEGE_NAME} | Page ${i} of ${pageCount}`, doc.internal.pageSize.width / 2, doc.internal.pageSize.height - 10, { align: 'center' });
  }

  doc.save('Kamaraj_Exam_Report.pdf');
}
